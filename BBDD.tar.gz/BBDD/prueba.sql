create table empleados(
            codigo int not null,
            nombre varchar(100) not null,
            lugar_nacimiento varchar(100) not null,
            fecha_nacimiento varchar(100) not null,
            direccion varchar(100) not null,
            telefono varchar(100) not null,
            puesto varchar(100) not null,
            primary key(codigo)
)
insert into usuario (usuario,pass,mail)
            values (user1, admin1, user1@gmail.com)
            insert into usuario(usuario,pass,mail)
            values(user2, admin2, user2@gmail.com)
            insert into usuario(usuario,pass,mail)
            values (user3, admin3, user3@gmail.com)
            
delete * from usuario;